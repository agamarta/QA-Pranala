<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Automation QA Pranala</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>cfefc1c1-e61f-458b-854f-ccf76d3b7388</testSuiteGuid>
   <testCaseLink>
      <guid>67e76035-105c-47ec-ae49-5496ffa7363a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Create Account</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>22bca70d-3c99-408b-8dbf-831c0ca7d792</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Create Account dengan jumlah password <5 char</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>b01c1db1-54c9-411a-8028-bf403ad6370f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Create Account dengan mengosongkan password</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>2ea4d22e-9605-4376-bb7f-764b5977a871</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Login</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>8664f237-3024-494b-b137-987dcf08ab4f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Mengganti bahasa</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>7d3f9d3d-73a6-4cd2-bccd-0e72cbfe8431</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Menginput huruf pada kolom no.HP di halaman create account</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>5c044ac1-feb9-472d-be3a-6dc00deaa13e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Create Account dengan jumlah password <5 char (1)</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>ceb70b87-a9ba-423f-9619-1aa9303dddc7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Create Account menggunakan alamat email yang
sama</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>355d8a61-e31b-4fb4-9834-751429c8b00c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Automation QA Pranala/Create Account tetapi tidak ceklist pada box
Agreements</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    